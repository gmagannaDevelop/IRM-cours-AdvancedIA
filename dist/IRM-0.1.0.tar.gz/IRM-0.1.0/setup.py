# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['irm', 'irm.experiment_synthetic']

package_data = \
{'': ['*']}

install_requires = \
['jax>=0.2.28,<0.3.0',
 'plotnine>=0.8.0,<0.9.0',
 'scikit-learn>=1.0.2,<2.0.0',
 'toml>=0.10.2,<0.11.0',
 'torch>=1.10.2,<2.0.0',
 'tqdm>=4.62.3,<5.0.0']

entry_points = \
{'console_scripts': ['irm = irm.__main__:main']}

setup_kwargs = {
    'name': 'irm',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'Gustavo Magaña López',
    'author_email': '28574085+gmagannaDevelop@users.noreply.github.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
